# Crop_Fertilizer_RS
Based on RS by using ML
